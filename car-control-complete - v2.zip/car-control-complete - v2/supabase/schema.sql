create extension if not exists pgcrypto;

create type usuario_uso as enum ('FELIPE', 'EVERTON');
create type status_uso as enum ('ABERTO', 'FINALIZADO');
create type tipo_despesa as enum ('FIXA', 'VARIAVEL');
create type forma_pagamento as enum ('A_VISTA','CARTAO','BOLETO','PIX','TRANSFERENCIA');
create type tipo_recorrencia as enum ('SEM_RECORRENCIA','SEMANAL','QUINZENAL','MENSAL','ANUAL');

create table if not exists categorias_despesa (
  id uuid primary key default gen_random_uuid(),
  nome text not null unique,
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

insert into categorias_despesa (nome)
select categoria from (values ('FINANCIAMENTO'),('IPVA'),('LICENCIAMENTO'),('SEGURO'),('MANUTENCAO'),('OLEO'),('PNEU'),('COMBUSTIVEL'),('LAVAGEM'),('OUTROS')) as t(categoria)
where not exists (select 1 from categorias_despesa c where c.nome = t.categoria);

create table if not exists app_settings (
  id uuid primary key default gen_random_uuid(),
  nome_app text not null default 'Controle do carro',
  proprietario_nome text not null default 'Felipe',
  segundo_condutor_nome text not null default 'Everton',
  usuario_principal usuario_uso not null default 'FELIPE',
  veiculo_padrao_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists veiculos (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  placa text not null,
  km_atual numeric(12,2) not null default 0,
  km_troca_oleo numeric(12,2) not null,
  ultima_troca_oleo_km numeric(12,2) not null,
  consumo_medio_km_litro numeric(12,2) not null,
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

alter table app_settings drop constraint if exists fk_app_settings_veiculo;
alter table app_settings add constraint fk_app_settings_veiculo foreign key (veiculo_padrao_id) references veiculos(id) on delete set null;

create table if not exists modelos_despesa (
  id uuid primary key default gen_random_uuid(),
  descricao text not null,
  categoria text not null,
  categoria_id uuid references categorias_despesa(id) on delete set null,
  tipo_despesa tipo_despesa not null,
  recorrente boolean not null default false,
  tipo_recorrencia tipo_recorrencia not null default 'SEM_RECORRENCIA',
  dia_recorrencia integer,
  quantidade_parcelas integer,
  observacao text,
  created_at timestamptz not null default now()
);

create table if not exists despesas (
  id uuid primary key default gen_random_uuid(),
  veiculo_id uuid not null references veiculos(id) on delete cascade,
  modelo_despesa_id uuid references modelos_despesa(id) on delete set null,
  descricao text not null,
  categoria text not null,
  categoria_id uuid references categorias_despesa(id) on delete set null,
  tipo_despesa tipo_despesa not null,
  valor numeric(12,2) not null,
  data_despesa date not null,
  vencimento date,
  pago boolean not null default false,
  forma_pagamento forma_pagamento not null default 'A_VISTA',
  cartao_titular text,
  recorrente boolean not null default false,
  tipo_recorrencia tipo_recorrencia not null default 'SEM_RECORRENCIA',
  dia_recorrencia integer,
  quantidade_parcelas integer,
  parcela_atual integer,
  observacao text,
  created_at timestamptz not null default now()
);

create table if not exists usos (
  id uuid primary key default gen_random_uuid(),
  veiculo_id uuid not null references veiculos(id) on delete cascade,
  usuario_uso usuario_uso not null,
  km_inicial numeric(12,2) not null,
  km_final numeric(12,2),
  km_rodado numeric(12,2),
  data_inicio timestamptz not null default now(),
  data_fim timestamptz,
  status status_uso not null default 'ABERTO',
  inferido boolean not null default false,
  observacao text,
  created_at timestamptz not null default now()
);

create index if not exists idx_despesas_data on despesas(data_despesa);
create index if not exists idx_usos_data on usos(data_inicio);
create index if not exists idx_usos_status on usos(status);
create index if not exists idx_usos_veiculo_user on usos(veiculo_id, usuario_uso, data_inicio desc);

create or replace function ensure_single_settings_row()
returns trigger language plpgsql as $$
begin
  if (select count(*) from app_settings) >= 1 and tg_op = 'INSERT' then
    raise exception 'Apenas uma configuração global é permitida';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_single_settings_row on app_settings;
create trigger trg_single_settings_row before insert on app_settings for each row execute function ensure_single_settings_row();

insert into app_settings (nome_app, proprietario_nome, segundo_condutor_nome, usuario_principal)
select 'Controle do carro', 'Felipe', 'Everton', 'FELIPE'
where not exists (select 1 from app_settings);

create or replace function start_felipe_use(p_veiculo_id uuid, p_km_inicial numeric, p_observacao text default null)
returns json language plpgsql as $$
declare
  v_open usos%rowtype;
  v_last_felipe usos%rowtype;
  v_inferido numeric := 0;
  v_new usos%rowtype;
begin
  select * into v_open from usos where veiculo_id = p_veiculo_id and usuario_uso = 'FELIPE' and status = 'ABERTO' order by data_inicio desc limit 1;
  if v_open.id is not null then
    raise exception 'Já existe um uso do Felipe em aberto';
  end if;

  select * into v_last_felipe
  from usos
  where veiculo_id = p_veiculo_id and usuario_uso = 'FELIPE' and status = 'FINALIZADO'
  order by data_fim desc nulls last, data_inicio desc limit 1;

  if v_last_felipe.id is not null then
    if p_km_inicial < coalesce(v_last_felipe.km_final, v_last_felipe.km_inicial) then
      raise exception 'O km inicial não pode ser menor que o último km final do Felipe';
    end if;

    v_inferido := p_km_inicial - coalesce(v_last_felipe.km_final, v_last_felipe.km_inicial);
    if v_inferido > 0 then
      insert into usos (veiculo_id, usuario_uso, km_inicial, km_final, km_rodado, data_inicio, data_fim, status, inferido, observacao)
      values (p_veiculo_id, 'EVERTON', coalesce(v_last_felipe.km_final, v_last_felipe.km_inicial), p_km_inicial, v_inferido, now(), now(), 'FINALIZADO', true, 'Uso inferido automaticamente entre um uso do Felipe e outro.');
    end if;
  end if;

  insert into usos (veiculo_id, usuario_uso, km_inicial, status, observacao, data_inicio)
  values (p_veiculo_id, 'FELIPE', p_km_inicial, 'ABERTO', p_observacao, now())
  returning * into v_new;

  update veiculos set km_atual = greatest(km_atual, p_km_inicial) where id = p_veiculo_id;

  return json_build_object(
    'message', 'Uso iniciado com sucesso',
    'usoId', v_new.id,
    'evertonKmInferido', v_inferido,
    'dataInicio', v_new.data_inicio
  );
end;
$$;

create or replace function finish_felipe_use(p_uso_id uuid, p_km_final numeric, p_observacao text default null)
returns json language plpgsql as $$
declare
  v_uso usos%rowtype;
  v_km numeric;
begin
  select * into v_uso from usos where id = p_uso_id and usuario_uso = 'FELIPE' and status = 'ABERTO';
  if v_uso.id is null then
    raise exception 'Uso aberto do Felipe não encontrado';
  end if;
  if p_km_final <= v_uso.km_inicial then
    raise exception 'O km final deve ser maior que o km inicial';
  end if;
  v_km := p_km_final - v_uso.km_inicial;

  update usos
  set km_final = p_km_final,
      km_rodado = v_km,
      data_fim = now(),
      status = 'FINALIZADO',
      observacao = coalesce(p_observacao, observacao)
  where id = p_uso_id;

  update veiculos set km_atual = greatest(km_atual, p_km_final) where id = v_uso.veiculo_id;

  return json_build_object('message', 'Uso finalizado com sucesso', 'kmRodado', v_km, 'dataFim', now());
end;
$$;

create or replace view vw_rateio_periodo as
with despesas_por_mes as (
  select veiculo_id, date_trunc('month', data_despesa::timestamp) as mes,
         sum(case when tipo_despesa = 'FIXA' then valor else 0 end) as total_fixas,
         sum(case when tipo_despesa = 'VARIAVEL' then valor else 0 end) as total_variaveis
  from despesas group by 1,2
),
km_por_mes as (
  select veiculo_id, date_trunc('month', coalesce(data_fim, data_inicio)) as mes, usuario_uso,
         sum(coalesce(km_rodado, 0)) as km_total_usuario
  from usos where status = 'FINALIZADO'
  group by 1,2,3
),
km_total as (
  select veiculo_id, mes, sum(km_total_usuario) as km_total_mes from km_por_mes group by 1,2
)
select k.veiculo_id, k.mes, k.usuario_uso, k.km_total_usuario, kt.km_total_mes, d.total_fixas, d.total_variaveis,
       case when kt.km_total_mes > 0 then round((k.km_total_usuario / kt.km_total_mes) * coalesce(d.total_variaveis, 0), 2) else 0 end as valor_variavel_rateado,
       case when k.usuario_uso = 'FELIPE' then coalesce(d.total_fixas, 0) else 0 end as valor_fixo_responsavel,
       (case when kt.km_total_mes > 0 then round((k.km_total_usuario / kt.km_total_mes) * coalesce(d.total_variaveis, 0), 2) else 0 end) +
       (case when k.usuario_uso = 'FELIPE' then coalesce(d.total_fixas, 0) else 0 end) as total_responsavel
from km_por_mes k
join km_total kt on kt.veiculo_id = k.veiculo_id and kt.mes = k.mes
left join despesas_por_mes d on d.veiculo_id = k.veiculo_id and d.mes = k.mes;

alter table app_settings enable row level security;
alter table veiculos enable row level security;
alter table categorias_despesa enable row level security;
alter table modelos_despesa enable row level security;
alter table despesas enable row level security;
alter table usos enable row level security;

create policy "allow all app_settings" on app_settings for all to authenticated using (true) with check (true);
create policy "allow all veiculos" on veiculos for all to authenticated using (true) with check (true);
create policy "allow all categorias_despesa" on categorias_despesa for all to authenticated using (true) with check (true);
create policy "allow all modelos_despesa" on modelos_despesa for all to authenticated using (true) with check (true);
create policy "allow all despesas" on despesas for all to authenticated using (true) with check (true);
create policy "allow all usos" on usos for all to authenticated using (true) with check (true);
